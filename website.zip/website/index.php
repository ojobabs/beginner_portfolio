<?
<!DOCTYPE HTML>
<html>
	<head>
		<title>Babatunde Victor</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<div id="wrapper">
			<div id="bg"></div>
			<div id="overlay"></div>
			<div id="main">

				<!-- Header -->
					<header id="header">
						<h1>Babatunde Victor</h1>
                        <p>Software developer &nbsp;&bull;&nbsp; AI|ML &nbsp;&bull;&nbsp; #Stay safe</p>
						<nav>
							<ul>
								<li><a href="https://twitter.com/babs_tinapa" class="icon brands fa-twitter"><span class="label">Twitter</span></a></li>
								<li><a href="https://linkedin.com/in/ojobabs" class="icon brands fa-linkedin"><span class="label">Dribbble</span></a></li>
								<li><a href="https://github.com/ojobabs" class="icon brands fa-github"><span class="label">Github</span></a></li>
								<li><a href="mailto:info@ojobabs.tech" class="icon solid fa-envelope"><span class="label">Email</span></a></li>
							</ul>
						</nav>
					</header>
					
				<!-- Footer -->
					<footer id="footer">
						<span class="copyright">&copy; <?php echo date("Y"); ?> Babatunde Victor.</span>
					</footer>

			</div>
		</div>
		<script>
			window.onload = function() { document.body.classList.remove('is-preload'); }
			window.ontouchmove = function() { return false; }
			window.onorientationchange = function() { document.body.scrollTop = 0; }
		</script>
	</body>
</html>
?>